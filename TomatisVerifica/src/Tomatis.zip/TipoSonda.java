public enum TipoSonda {
    FOTOSENSORI,
    AUDIOSENSORI,
    RADIOSENSORI
}
