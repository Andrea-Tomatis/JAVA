public interface CorpoSolido {
    public abstract double getPeso();
}
