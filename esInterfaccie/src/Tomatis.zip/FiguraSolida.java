public interface FiguraSolida {

    public abstract double getSuperficie();
    public abstract double getVolume();
}
